<?php $this->layout('temp/layout_base', ['title' => $title]) ?>

<?=$this->section('content')?>